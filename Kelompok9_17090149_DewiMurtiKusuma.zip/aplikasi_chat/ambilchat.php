<?php 
mysql_connect("localhost","root","");
mysql_select_db("chat");

$nama = $_GET ['nama'];
$pesan = $_GET['pesan'];
$waktu = date("H:i");
$akhir = $_GET['akhir'];

$json = '{"messages": {';
if($akhir==0){
	$nomor = mysql_query("select nomor from drzchat order by nomor desc limit 1");
	$n = mysql_fetch_array($nomor);
	$no = $n['nomor'] + 1;
	$json .= '"pesan": [ {';
	$json .= '"id":"'.$no.'",
			  "nama":"Admin",
			  "teks":"Selamat datang di chatting room",
			  "waktu":"'.$waktu.'"
			}]';
	$masuk = mysql_query("insert into drzchat values(null,'Admin','$nama bergabung dalam chat','$waktu')");
}else{
	if($pesan){
		$masuk = mysql_query("insert into drzchat values(null,'$nama','$pesan','$waktu')");
	}
		$query = mysql_query("select * from drzchat where nomor > $akhir");
		$json .= '"pesan":[ ';
		while ($x = mysql_fetch_array($query)) {
			$json .= '{';
			$json .= '"id":"'.$x['nomor'].'",
					  "nama":"'.htmlspecialchars($x['nama']).'",
					  "teks":"'.htmlspecialchars($x['pesan']).'",
					},';
		}
		$json = substr($json,0,strlen($json)-1);
		$json .=']';
	}

	$json .= '}}';
	echo $json;
 ?>